package com.example.simplememo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplememoApplicationTests {

	@Test
	void contextLoads() {
	}

}
